import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './emp/employee.component';
import { ListEmployeesComponent } from './employees/list-employees.component';
import { CreateEmployeeComponent } from './employees/create-employee.component';

import { RouterModule, Routes } from '@angular/router';
const appRoutes: Routes = [
    { path: 'list', component: ListEmployeesComponent },
    { path: 'create', component: CreateEmployeeComponent },
    { path: '', redirectTo: '/list', pathMatch: 'full' }
  ];

@NgModule({
    imports: [BrowserModule,RouterModule.forRoot(appRoutes)],
    declarations: [AppComponent, EmployeeComponent, ListEmployeesComponent, CreateEmployeeComponent],
    bootstrap: [AppComponent]
})


  

export class AppModule { }
